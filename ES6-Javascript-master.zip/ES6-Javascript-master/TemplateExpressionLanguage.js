function templateFunction(name, type){
    return `Company Name: ${name}  of type : ${type}
    From Bangalore `
}
console.log(templateFunction('SAP', 'Private LTD'));


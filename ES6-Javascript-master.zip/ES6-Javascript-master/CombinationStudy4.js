"use strict";

var a = "first";
var b = "second";

[b, a] = [a, b];

console.log(a, b);

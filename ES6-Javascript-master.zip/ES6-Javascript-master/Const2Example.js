"use strict"

//const arr =[1,2];
var arr = [1,2];

arr.push(3);

console.log(arr);

arr = [1,2,3,4];

console.log(arr);

